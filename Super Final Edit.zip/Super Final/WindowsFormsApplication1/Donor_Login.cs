﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Donor_Login : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlCommand cmd;

        public Donor_Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void show_data()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT P.p_name AS Name, P.addr AS Address, P.num AS Phone_Number, P.b_group AS Blood_Type, P.med_report AS Medical_History FROM Profiles P, Donors D, Collect C WHERE C.did = D.did AND D.did = @did AND P.SSN = @SSN", con);

            cmd.Parameters.AddWithValue("@did", textBox_donordid.Text);
            cmd.Parameters.AddWithValue("@SSN", textBox_donorSSN.Text);
            

            SqlDataAdapter adapt = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            adapt.SelectCommand = cmd;

            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button_login_Click(object sender, EventArgs e)
        {
            if (textBox_donordid.Text == "" || textBox_donorSSN.Text == "")
            {
                MessageBox.Show("Please fill out all required fields!");
                return;
            }

            show_data();
        }

        private void textBox_donordid_TextChanged(object sender, EventArgs e)
        {

        }

        private void Donor_Login_Load(object sender, EventArgs e)
        {

        }
    }
}
