﻿namespace WindowsFormsApplication1
{
    partial class BloodBank
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_bloodbankname = new System.Windows.Forms.Label();
            this.textBox_bloodbankname = new System.Windows.Forms.TextBox();
            this.button_view = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button_insert = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.button_sort = new System.Windows.Forms.Button();
            this.button_average = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // label_bloodbankname
            // 
            this.label_bloodbankname.AutoSize = true;
            this.label_bloodbankname.Location = new System.Drawing.Point(73, 65);
            this.label_bloodbankname.Name = "label_bloodbankname";
            this.label_bloodbankname.Size = new System.Drawing.Size(93, 13);
            this.label_bloodbankname.TabIndex = 0;
            this.label_bloodbankname.Text = "Blood Bank Name";
            // 
            // textBox_bloodbankname
            // 
            this.textBox_bloodbankname.Location = new System.Drawing.Point(199, 62);
            this.textBox_bloodbankname.Name = "textBox_bloodbankname";
            this.textBox_bloodbankname.Size = new System.Drawing.Size(333, 20);
            this.textBox_bloodbankname.TabIndex = 2;
            this.textBox_bloodbankname.TextChanged += new System.EventHandler(this.textBox_bloodbankname_TextChanged);
            // 
            // button_view
            // 
            this.button_view.Location = new System.Drawing.Point(581, 60);
            this.button_view.Name = "button_view";
            this.button_view.Size = new System.Drawing.Size(75, 23);
            this.button_view.TabIndex = 4;
            this.button_view.Text = "Search";
            this.button_view.UseVisualStyleBackColor = true;
            this.button_view.Click += new System.EventHandler(this.button_view_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(26, 177);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(680, 278);
            this.dataGridView2.TabIndex = 5;
            // 
            // button_insert
            // 
            this.button_insert.Location = new System.Drawing.Point(57, 134);
            this.button_insert.Name = "button_insert";
            this.button_insert.Size = new System.Drawing.Size(123, 23);
            this.button_insert.TabIndex = 6;
            this.button_insert.Text = "Insert New Profile";
            this.button_insert.UseVisualStyleBackColor = true;
            this.button_insert.Click += new System.EventHandler(this.button_insert_Click);
            // 
            // button_delete
            // 
            this.button_delete.Location = new System.Drawing.Point(313, 134);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(125, 23);
            this.button_delete.TabIndex = 7;
            this.button_delete.Text = "Delete Profile";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // button_update
            // 
            this.button_update.Location = new System.Drawing.Point(552, 134);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(123, 23);
            this.button_update.TabIndex = 8;
            this.button_update.Text = "Update Profile";
            this.button_update.UseVisualStyleBackColor = true;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // button_sort
            // 
            this.button_sort.Location = new System.Drawing.Point(199, 473);
            this.button_sort.Name = "button_sort";
            this.button_sort.Size = new System.Drawing.Size(122, 23);
            this.button_sort.TabIndex = 9;
            this.button_sort.Text = "Sort Profiles";
            this.button_sort.UseVisualStyleBackColor = true;
            this.button_sort.Click += new System.EventHandler(this.button_sort_Click);
            // 
            // button_average
            // 
            this.button_average.Location = new System.Drawing.Point(410, 473);
            this.button_average.Name = "button_average";
            this.button_average.Size = new System.Drawing.Size(122, 23);
            this.button_average.TabIndex = 10;
            this.button_average.Text = "Count Blood Types";
            this.button_average.UseVisualStyleBackColor = true;
            this.button_average.Click += new System.EventHandler(this.button_average_Click);
            // 
            // BloodBank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 522);
            this.Controls.Add(this.button_average);
            this.Controls.Add(this.button_sort);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.button_insert);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button_view);
            this.Controls.Add(this.textBox_bloodbankname);
            this.Controls.Add(this.label_bloodbankname);
            this.Name = "BloodBank";
            this.Text = "BloodBank";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_bloodbankname;
        private System.Windows.Forms.TextBox textBox_bloodbankname;
        private System.Windows.Forms.Button button_view;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button_insert;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Button button_sort;
        private System.Windows.Forms.Button button_average;
    }
}