﻿namespace WindowsFormsApplication1
{
    partial class ProfileInsert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_name = new System.Windows.Forms.Label();
            this.label_ssn = new System.Windows.Forms.Label();
            this.label_num = new System.Windows.Forms.Label();
            this.label_addr = new System.Windows.Forms.Label();
            this.label_b_group = new System.Windows.Forms.Label();
            this.label_med_report = new System.Windows.Forms.Label();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.textBox_ssn = new System.Windows.Forms.TextBox();
            this.textBox_num = new System.Windows.Forms.TextBox();
            this.textBox_addr = new System.Windows.Forms.TextBox();
            this.textBox_b_group = new System.Windows.Forms.TextBox();
            this.textBox_med_report = new System.Windows.Forms.TextBox();
            this.button_insert = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Location = new System.Drawing.Point(90, 50);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(42, 13);
            this.label_name.TabIndex = 0;
            this.label_name.Text = "Name *";
            this.label_name.Click += new System.EventHandler(this.label1_Click);
            // 
            // label_ssn
            // 
            this.label_ssn.AutoSize = true;
            this.label_ssn.Location = new System.Drawing.Point(90, 88);
            this.label_ssn.Name = "label_ssn";
            this.label_ssn.Size = new System.Drawing.Size(36, 13);
            this.label_ssn.TabIndex = 1;
            this.label_ssn.Text = "SSN *";
            // 
            // label_num
            // 
            this.label_num.AutoSize = true;
            this.label_num.Location = new System.Drawing.Point(90, 125);
            this.label_num.Name = "label_num";
            this.label_num.Size = new System.Drawing.Size(85, 13);
            this.label_num.TabIndex = 2;
            this.label_num.Text = "Phone Number *";
            // 
            // label_addr
            // 
            this.label_addr.AutoSize = true;
            this.label_addr.Location = new System.Drawing.Point(90, 160);
            this.label_addr.Name = "label_addr";
            this.label_addr.Size = new System.Drawing.Size(52, 13);
            this.label_addr.TabIndex = 3;
            this.label_addr.Text = "Address *";
            // 
            // label_b_group
            // 
            this.label_b_group.AutoSize = true;
            this.label_b_group.Location = new System.Drawing.Point(90, 195);
            this.label_b_group.Name = "label_b_group";
            this.label_b_group.Size = new System.Drawing.Size(71, 13);
            this.label_b_group.TabIndex = 4;
            this.label_b_group.Text = "Blood Type  *";
            // 
            // label_med_report
            // 
            this.label_med_report.AutoSize = true;
            this.label_med_report.Location = new System.Drawing.Point(90, 227);
            this.label_med_report.Name = "label_med_report";
            this.label_med_report.Size = new System.Drawing.Size(79, 13);
            this.label_med_report.TabIndex = 5;
            this.label_med_report.Text = "Medical Report";
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(205, 47);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(182, 20);
            this.textBox_name.TabIndex = 6;
            this.textBox_name.TextChanged += new System.EventHandler(this.textBox_name_TextChanged);
            // 
            // textBox_ssn
            // 
            this.textBox_ssn.Location = new System.Drawing.Point(205, 85);
            this.textBox_ssn.Name = "textBox_ssn";
            this.textBox_ssn.Size = new System.Drawing.Size(182, 20);
            this.textBox_ssn.TabIndex = 7;
            this.textBox_ssn.TextChanged += new System.EventHandler(this.textBox_ssn_TextChanged);
            // 
            // textBox_num
            // 
            this.textBox_num.Location = new System.Drawing.Point(205, 125);
            this.textBox_num.Name = "textBox_num";
            this.textBox_num.Size = new System.Drawing.Size(182, 20);
            this.textBox_num.TabIndex = 8;
            // 
            // textBox_addr
            // 
            this.textBox_addr.Location = new System.Drawing.Point(205, 160);
            this.textBox_addr.Name = "textBox_addr";
            this.textBox_addr.Size = new System.Drawing.Size(182, 20);
            this.textBox_addr.TabIndex = 9;
            // 
            // textBox_b_group
            // 
            this.textBox_b_group.Location = new System.Drawing.Point(205, 195);
            this.textBox_b_group.Name = "textBox_b_group";
            this.textBox_b_group.Size = new System.Drawing.Size(182, 20);
            this.textBox_b_group.TabIndex = 10;
            // 
            // textBox_med_report
            // 
            this.textBox_med_report.Location = new System.Drawing.Point(205, 227);
            this.textBox_med_report.Name = "textBox_med_report";
            this.textBox_med_report.Size = new System.Drawing.Size(182, 20);
            this.textBox_med_report.TabIndex = 11;
            // 
            // button_insert
            // 
            this.button_insert.Location = new System.Drawing.Point(173, 287);
            this.button_insert.Name = "button_insert";
            this.button_insert.Size = new System.Drawing.Size(148, 23);
            this.button_insert.TabIndex = 12;
            this.button_insert.Text = "Create Profile";
            this.button_insert.UseVisualStyleBackColor = true;
            this.button_insert.Click += new System.EventHandler(this.button_insert_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "* Indicates required field";
            // 
            // ProfileInsert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 360);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_insert);
            this.Controls.Add(this.textBox_med_report);
            this.Controls.Add(this.textBox_b_group);
            this.Controls.Add(this.textBox_addr);
            this.Controls.Add(this.textBox_num);
            this.Controls.Add(this.textBox_ssn);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.label_med_report);
            this.Controls.Add(this.label_b_group);
            this.Controls.Add(this.label_addr);
            this.Controls.Add(this.label_num);
            this.Controls.Add(this.label_ssn);
            this.Controls.Add(this.label_name);
            this.Name = "ProfileInsert";
            this.Text = "ProfileInsert";
            this.Load += new System.EventHandler(this.ProfileInsert_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_ssn;
        private System.Windows.Forms.Label label_num;
        private System.Windows.Forms.Label label_addr;
        private System.Windows.Forms.Label label_b_group;
        private System.Windows.Forms.Label label_med_report;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.TextBox textBox_ssn;
        private System.Windows.Forms.TextBox textBox_num;
        private System.Windows.Forms.TextBox textBox_addr;
        private System.Windows.Forms.TextBox textBox_b_group;
        private System.Windows.Forms.TextBox textBox_med_report;
        private System.Windows.Forms.Button button_insert;
        private System.Windows.Forms.Label label1;
    }
}