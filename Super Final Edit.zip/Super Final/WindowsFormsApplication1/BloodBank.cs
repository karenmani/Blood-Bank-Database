﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class BloodBank : Form
    {
        SqlConnection con3 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlConnection con4 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlCommand cmd3;
        SqlCommand cmd4;
        SqlConnection con5 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlCommand cmd5;
        SqlConnection con6 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlCommand cmd6;
        SqlConnection con7 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlCommand cmd7;

        public BloodBank()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void show_data()
        {
            con3.Open();
            SqlCommand cmd3 = new SqlCommand("SELECT DISTINCT B.b_name AS Blood_Bank_Name, B.b_num AS Phone_Number, B.b_address AS Address FROM BloodBanks B WHERE B.b_name = @b_name", con3);
            
            cmd3.Parameters.AddWithValue("@b_name", textBox_bloodbankname.Text);

            SqlDataAdapter adapt5 = new SqlDataAdapter(cmd3);
            DataTable dt5 = new DataTable();

            adapt5.SelectCommand = cmd3;

            adapt5.Fill(dt5);
            dataGridView2.DataSource = dt5;
            con3.Close();
        }

        private void button_view_Click(object sender, EventArgs e)
        {
            if (textBox_bloodbankname.Text == "")
            {
                MessageBox.Show("Invalid Blood Bank name!");
                return;
            }

            show_data();
        }

        private void button_sort_Click(object sender, EventArgs e)
        {
            con4.Open();
            SqlCommand cmd4 = new SqlCommand("SELECT DISTINCT P.p_name AS Name, P.addr AS Address, P.num AS Phone_Number, P.b_group AS Blood_Type, P.med_report AS Medical_History FROM Profiles P, Patients X, Donors Y, Collect C, Donate D WHERE D.pid = X.pid AND C.did = Y.did ORDER BY P.p_name ASC", con4);

            SqlDataAdapter adapt1 = new SqlDataAdapter(cmd4);
            DataTable dt1 = new DataTable();

            adapt1.SelectCommand = cmd4;

            adapt1.Fill(dt1);
            dataGridView2.DataSource = dt1;
            con4.Close();
        }

        private void button_average_Click(object sender, EventArgs e)
        {
            con6.Open();
            SqlCommand cmd6 = new SqlCommand("SELECT P.b_group AS Blood_Group, COUNT(*) AS Blood_Type_Count FROM Profiles P GROUP BY P.b_group", con6);

            SqlDataAdapter ad = new SqlDataAdapter(cmd6);
            DataTable d = new DataTable();

            ad.SelectCommand = cmd6;

            ad.Fill(d);
            dataGridView2.DataSource = d;
            con6.Close();
        }

        private void textBox_bloodbankname_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_insert_Click(object sender, EventArgs e)
        {
            ProfileInsert prof = new ProfileInsert();
            prof.Show();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            ProfileDelete del = new ProfileDelete();
            del.Show();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            ProfileUpdate upd = new ProfileUpdate();
            upd.Show();
        }
    }
}
