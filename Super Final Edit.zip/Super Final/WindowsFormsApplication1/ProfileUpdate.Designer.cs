﻿namespace WindowsFormsApplication1
{
    partial class ProfileUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_name = new System.Windows.Forms.Label();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.label_updated_med_report = new System.Windows.Forms.Label();
            this.textBox_updated_med_report = new System.Windows.Forms.TextBox();
            this.button_update = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Location = new System.Drawing.Point(111, 35);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(48, 13);
            this.label_name.TabIndex = 0;
            this.label_name.Text = "Name *  ";
            this.label_name.Click += new System.EventHandler(this.label_name_Click);
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(182, 32);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(182, 20);
            this.textBox_name.TabIndex = 1;
            this.textBox_name.TextChanged += new System.EventHandler(this.textBox_name_TextChanged);
            // 
            // label_updated_med_report
            // 
            this.label_updated_med_report.AutoSize = true;
            this.label_updated_med_report.Location = new System.Drawing.Point(36, 71);
            this.label_updated_med_report.Name = "label_updated_med_report";
            this.label_updated_med_report.Size = new System.Drawing.Size(123, 13);
            this.label_updated_med_report.TabIndex = 2;
            this.label_updated_med_report.Text = "Updated Medical Report";
            // 
            // textBox_updated_med_report
            // 
            this.textBox_updated_med_report.Location = new System.Drawing.Point(182, 68);
            this.textBox_updated_med_report.Name = "textBox_updated_med_report";
            this.textBox_updated_med_report.Size = new System.Drawing.Size(182, 20);
            this.textBox_updated_med_report.TabIndex = 3;
            // 
            // button_update
            // 
            this.button_update.Location = new System.Drawing.Point(220, 104);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(98, 23);
            this.button_update.TabIndex = 4;
            this.button_update.Text = "Update Profile";
            this.button_update.UseVisualStyleBackColor = true;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "* Indicates required field";
            // 
            // ProfileUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 155);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_update);
            this.Controls.Add(this.textBox_updated_med_report);
            this.Controls.Add(this.label_updated_med_report);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.label_name);
            this.Name = "ProfileUpdate";
            this.Text = "ProfileUpdate";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Label label_updated_med_report;
        private System.Windows.Forms.TextBox textBox_updated_med_report;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Label label1;
    }
}