﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class ProfileUpdate : Form
    {
        SqlConnection con11 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlCommand cmd11;

        public ProfileUpdate()
        {
            InitializeComponent();
        }

        private void ClearData()
        {
            textBox_name.Text = "";
            textBox_updated_med_report.Text = "";
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            if (textBox_name.Text == "")
            {
                MessageBox.Show("Please fill out all the required fields!");
            }
            else
            {
                try
                {
                    con11.Open();
                    SqlCommand cmd11 = new SqlCommand("UPDATE Profiles SET Profiles.med_report = @med_report WHERE Profiles.p_name = @p_name", con11);
                    cmd11.Parameters.AddWithValue("@med_report", textBox_updated_med_report.Text);
                    cmd11.Parameters.AddWithValue("@p_name", textBox_name.Text);
                    cmd11.ExecuteNonQuery();
                    con11.Close();
                    MessageBox.Show("Profile has been updated!");
                    ClearData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    con11.Close();
                    ClearData();
                }
            }
        }

        private void label_name_Click(object sender, EventArgs e)
        {

        }

        private void textBox_name_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
