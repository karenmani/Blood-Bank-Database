﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
       
    public partial class ProfileInsert : Form
    {
        SqlConnection con9 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlCommand cmd9;

        public ProfileInsert()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ProfileInsert_Load(object sender, EventArgs e)
        {

        }

        private void ClearData()
        {
            textBox_name.Text = "";
            textBox_ssn.Text = "";
            textBox_num.Text = "";
            textBox_addr.Text = "";
            textBox_b_group.Text = "";
            textBox_med_report.Text = ""; 
        }

        private void button_insert_Click(object sender, EventArgs e)
        {
            if (textBox_name.Text == "" || textBox_ssn.Text == "" || textBox_num.Text == "" || textBox_addr.Text == "" || textBox_b_group.Text == "")
            {
                MessageBox.Show("Please fill out all the fields!");
            }
            else
            {
                try
                {
                    con9.Open();
                    SqlCommand cmd9 = new SqlCommand("INSERT INTO Profiles(Profiles.p_name, Profiles.SSN, Profile.num, Profiles.addr, Profiles.b_group, Profiles.med_report) VALUES (@p_name, @SSN, @num, @addr, @b_group, @med_report)", con9);

                    cmd9.Parameters.AddWithValue("@p_name", textBox_name.Text);
                    cmd9.Parameters.AddWithValue("@SSN", textBox_ssn.Text);
                    cmd9.Parameters.AddWithValue("@num", textBox_num.Text);
                    cmd9.Parameters.AddWithValue("@addr", textBox_addr.Text);
                    cmd9.Parameters.AddWithValue("@b_group", textBox_b_group.Text);
                    cmd9.Parameters.AddWithValue("@med_report", textBox_med_report.Text);
                    cmd9.ExecuteNonQuery();
                    con9.Close();
                    MessageBox.Show("Profile Inserted Successfully");
                    ClearData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    con9.Close();
                    ClearData();
                }
            }
        }

        private void textBox_ssn_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_name_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
