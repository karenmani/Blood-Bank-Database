﻿CREATE VIEW Blood_Donation_Center
AS SELECT b_num
FROM BloodBanks
WHERE b_name = 'Blood Donation Center';