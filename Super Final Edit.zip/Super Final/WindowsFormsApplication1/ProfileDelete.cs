﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class ProfileDelete : Form
    {
        SqlConnection con10 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlCommand cmd10;

        public ProfileDelete()
        {
            InitializeComponent();
        }

        private void ClearData()
        {
            textBox_name.Text = "";
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            if (textBox_name.Text == "")
            {
                MessageBox.Show("Please input a valid name!");
            }
            else
            {
                try
                {
                    cmd10 = new SqlCommand("DELETE FROM Profiles WHERE Profiles.p_name = @name", con10);
                    con10.Open();
                    cmd10.Parameters.AddWithValue("@name", textBox_name.Text);
                    cmd10.ExecuteNonQuery();
                    con10.Close();
                    MessageBox.Show("Record is deleted!");
                    ClearData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    con10.Close();
                    ClearData();
                }
            }
        }

        private void textBox_name_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
