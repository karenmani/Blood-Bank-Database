﻿DELETE FROM Donors WHERE did = 209;
SELECT * FROM op_log;