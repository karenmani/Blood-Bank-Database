﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class BloodBankHomepage : Form
    {
        public BloodBankHomepage()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_login_Click(object sender, EventArgs e)
        {
            Patient_Login pnt = new Patient_Login();
            pnt.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Donor_Login dnr = new Donor_Login();
            dnr.Show();
        }

        private void button_bloodbank_Click(object sender, EventArgs e)
        {
            BloodBank bbank = new BloodBank();
            bbank.Show();
        }
    }
}
