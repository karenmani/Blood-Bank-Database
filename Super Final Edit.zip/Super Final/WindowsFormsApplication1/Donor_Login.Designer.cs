﻿namespace WindowsFormsApplication1
{
    partial class Donor_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_donordid = new System.Windows.Forms.Label();
            this.label_donorSSN = new System.Windows.Forms.Label();
            this.textBox_donordid = new System.Windows.Forms.TextBox();
            this.textBox_donorSSN = new System.Windows.Forms.TextBox();
            this.button_login = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label_donordid
            // 
            this.label_donordid.AutoSize = true;
            this.label_donordid.Location = new System.Drawing.Point(67, 78);
            this.label_donordid.Name = "label_donordid";
            this.label_donordid.Size = new System.Drawing.Size(57, 13);
            this.label_donordid.TabIndex = 0;
            this.label_donordid.Text = "Donor ID *";
            this.label_donordid.Click += new System.EventHandler(this.label1_Click);
            // 
            // label_donorSSN
            // 
            this.label_donorSSN.AutoSize = true;
            this.label_donorSSN.Location = new System.Drawing.Point(67, 144);
            this.label_donorSSN.Name = "label_donorSSN";
            this.label_donorSSN.Size = new System.Drawing.Size(36, 13);
            this.label_donorSSN.TabIndex = 1;
            this.label_donorSSN.Text = "SSN *";
            // 
            // textBox_donordid
            // 
            this.textBox_donordid.Location = new System.Drawing.Point(130, 75);
            this.textBox_donordid.Name = "textBox_donordid";
            this.textBox_donordid.Size = new System.Drawing.Size(100, 20);
            this.textBox_donordid.TabIndex = 2;
            this.textBox_donordid.TextChanged += new System.EventHandler(this.textBox_donordid_TextChanged);
            // 
            // textBox_donorSSN
            // 
            this.textBox_donorSSN.Location = new System.Drawing.Point(130, 141);
            this.textBox_donorSSN.Name = "textBox_donorSSN";
            this.textBox_donorSSN.Size = new System.Drawing.Size(100, 20);
            this.textBox_donorSSN.TabIndex = 3;
            // 
            // button_login
            // 
            this.button_login.Location = new System.Drawing.Point(142, 201);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(75, 23);
            this.button_login.TabIndex = 4;
            this.button_login.Text = "View";
            this.button_login.UseVisualStyleBackColor = true;
            this.button_login.Click += new System.EventHandler(this.button_login_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(298, 35);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(346, 260);
            this.dataGridView1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "* Indicates required field";
            // 
            // Donor_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 330);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button_login);
            this.Controls.Add(this.textBox_donorSSN);
            this.Controls.Add(this.textBox_donordid);
            this.Controls.Add(this.label_donorSSN);
            this.Controls.Add(this.label_donordid);
            this.Name = "Donor_Login";
            this.Text = "Donor Login";
            this.Load += new System.EventHandler(this.Donor_Login_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_donordid;
        private System.Windows.Forms.Label label_donorSSN;
        private System.Windows.Forms.TextBox textBox_donordid;
        private System.Windows.Forms.TextBox textBox_donorSSN;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
    }
}