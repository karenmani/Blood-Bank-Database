﻿CREATE TABLE Patients(
       pid int PRIMARY KEY,
       );
 
INSERT INTO Patients VALUES
(100),
(101),
(102),
(103),
(104),
(105),
(106),
(107),
(108),
(109),
(110),
(111),
(112),
(113)
 
/*table for Donor*/
CREATE TABLE Donors(
       did int PRIMARY KEY,
       );
 
INSERT INTO Donors VALUES
(200),
(201),
(202),
(203),
(204),
(205),
(206),
(207),
(208),
(209)
 
CREATE TABLE Profiles(
       SSN int PRIMARY KEY,
       p_name varchar(50),
       b_group varchar(50),
       med_report varchar(50),
       addr varchar(50),
       num varchar(10),
       );
 
INSERT INTO Profiles VALUES
(312085335, 'Karen Mani', 'AB+', 'hemophilia', '123 Cherry Lane', '2027857347'),
(549330490, 'Yevgeny Smolyansky', 'O-', NULL, '263 Berwind Road', '6103899547'),
(473849203, 'Ethan Smith', 'A+', NULL, '1600 Penn Ave', '2027383743'),
(423912947, 'John Doe', 'O-', 'anemia', '2100 F St NW', '3567283647'),
(782584039, 'Sarah Smith', 'B-', 'diabetes', '1900 F St NW', '4672938989'),
(187048593, 'Jack Black', 'O-', NULL, '42 Wallaby Way', '2025647122'),
(672957384, 'Lyndsay Goldstein', 'A-', 'anxiety', '787 I St', '7839238484'),
(957204930, 'Mary Jane', 'AB+', 'brain bleed', '78 Oak Lane', '9004392323'),
(111111111, 'Hal Irish', 'B+', NULL, '672 Peach Tree Road', '8006102022'),
(121212121, 'Jeremiah Smith', 'O+', 'hypochondria', '808 Sesame St', '9093237483'),
(131658484, 'Warby Parker', 'A-', 'blind', '56 Beech Tree Road', '6009871234'),
(432824940, 'Stephen Morris', 'AB-', NULL, '15 Pine St', '7817295431'),
(284582403, 'Hannah Glaser', 'B-', 'POTS', '2400 M St', '3108905678'),
(185939040, 'Kennedy Young', 'AB+', 'pregnant', '78 A St', '9087789672'),
(120583039, 'Lily Jacobs', 'O-', NULL, '678 Kensico St', '9084328743'),
(420548205, 'John Hudson', 'AB+', 'HIV', '10 Ocean Drive', '3657646732'),
(104492049, 'Joseph Parks', 'O+', NULL, '4 23rd St', '9098473241'),
(194803492, 'Julia Roberts', 'AB-', 'HPV', '23 Beverly Hills Dr', '5637281234'),
(238404025, 'Sasha Smolyansky', 'O+', NULL, '469 Merriweather Road', '3920483029'),
(830248022, 'Lei He', 'B-', NULL, '800 21 St NW', '5739294574'),
(955832433, 'Jesse McCartney', 'A+', 'AIDS', '123 Hive Road', '9894620876'),
(197639573, 'Estelle Gelman', 'AB-', 'high blood pressure', '2100 H St NW', '2029945609')
 
CREATE TABLE BloodBanks(
       b_name varchar(100) PRIMARY KEY,
       b_address varchar(50),
       b_num varchar(50),
       );
 
INSERT INTO BloodBanks VALUES
('American Red Cross Blood Donation Center', '1900 Penn Ave', '2026758940'),
('Hong Kong Red Cross Blood Transfusion Service', '200 3rd St', '8902389393'),
('Inova Blood Donor Services', '23 F St', '9098765432'),
('Blood Donation Center', '1 Central Park Ave', '6009006767')
 
CREATE TABLE Donate(
       pid int,
       b_name varchar(100),
       FOREIGN KEY(pid) REFERENCES Patients,
       FOREIGN KEY(b_name) REFERENCES BloodBanks,
       PRIMARY KEY(pid, b_name),
       );
 
INSERT INTO Donate VALUES
(101, 'Blood Donation Center'),
(102, 'Blood Donation Center'),
(103, 'Blood Donation Center'),
(107, 'Hong Kong Red Cross Blood Transfusion Service'),
(108, 'Hong Kong Red Cross Blood Transfusion Service'),
(109, 'American Red Cross Blood Donation Center')
 
CREATE TABLE Collect(
       did int,
       b_name varchar(100),
       FOREIGN KEY(did) REFERENCES Donors,
       FOREIGN KEY(b_name) REFERENCES BloodBanks,
       PRIMARY KEY(did, b_name),
       );
 
INSERT INTO Collect VALUES
(200, 'Blood Donation Center'),
(201, 'Blood Donation Center'),
(202, 'Blood Donation Center'),
(203, 'American Red Cross Blood Donation Center'),
(204, 'Blood Donation Center'),
(207, 'Blood Donation Center')

