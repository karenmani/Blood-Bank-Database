﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Patient_Login : Form
    {
        SqlConnection con2 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
        SqlCommand cmd2;
        public Patient_Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void show_data()
        {
            con2.Open();
            SqlCommand cmd2 = new SqlCommand("SELECT P.p_name AS Name, P.addr AS Address, P.num AS Phone_Number, P.b_group AS Blood_Type, P.med_report AS Medical_History FROM Profiles P, Patients X, Donate D WHERE X.pid = D.pid AND D.pid = @pid AND P.SSN = @SSN", con2);

            cmd2.Parameters.AddWithValue("@pid", textBox_patientpid.Text);
            cmd2.Parameters.AddWithValue("@SSN", textBox_patientssn.Text);


            SqlDataAdapter adapt2 = new SqlDataAdapter(cmd2);
            DataTable dt2 = new DataTable();

            adapt2.SelectCommand = cmd2;

            adapt2.Fill(dt2);
            dataGridView3.DataSource = dt2;
            con2.Close();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button_login_Click(object sender, EventArgs e)
        {
            if (textBox_patientpid.Text == "" || textBox_patientssn.Text == "")
            {
                MessageBox.Show("Please fill out all required fields!");
                return;
            }

            show_data();
        }

        private void textBox_patientssn_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_patientpid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
