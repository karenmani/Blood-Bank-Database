﻿namespace WindowsFormsApplication1
{
    partial class Patient_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_patientpid = new System.Windows.Forms.Label();
            this.label_patientssn = new System.Windows.Forms.Label();
            this.textBox_patientpid = new System.Windows.Forms.TextBox();
            this.textBox_patientssn = new System.Windows.Forms.TextBox();
            this.button_login = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // label_patientpid
            // 
            this.label_patientpid.AutoSize = true;
            this.label_patientpid.Location = new System.Drawing.Point(81, 92);
            this.label_patientpid.Name = "label_patientpid";
            this.label_patientpid.Size = new System.Drawing.Size(61, 13);
            this.label_patientpid.TabIndex = 0;
            this.label_patientpid.Text = "Patient ID *";
            this.label_patientpid.Click += new System.EventHandler(this.label1_Click);
            // 
            // label_patientssn
            // 
            this.label_patientssn.AutoSize = true;
            this.label_patientssn.Location = new System.Drawing.Point(90, 145);
            this.label_patientssn.Name = "label_patientssn";
            this.label_patientssn.Size = new System.Drawing.Size(36, 13);
            this.label_patientssn.TabIndex = 1;
            this.label_patientssn.Text = "SSN *";
            this.label_patientssn.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // textBox_patientpid
            // 
            this.textBox_patientpid.Location = new System.Drawing.Point(152, 89);
            this.textBox_patientpid.Name = "textBox_patientpid";
            this.textBox_patientpid.Size = new System.Drawing.Size(100, 20);
            this.textBox_patientpid.TabIndex = 2;
            this.textBox_patientpid.TextChanged += new System.EventHandler(this.textBox_patientpid_TextChanged);
            // 
            // textBox_patientssn
            // 
            this.textBox_patientssn.Location = new System.Drawing.Point(152, 142);
            this.textBox_patientssn.Name = "textBox_patientssn";
            this.textBox_patientssn.Size = new System.Drawing.Size(100, 20);
            this.textBox_patientssn.TabIndex = 3;
            this.textBox_patientssn.TextChanged += new System.EventHandler(this.textBox_patientssn_TextChanged);
            // 
            // button_login
            // 
            this.button_login.Location = new System.Drawing.Point(152, 196);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(75, 23);
            this.button_login.TabIndex = 4;
            this.button_login.Text = "Login";
            this.button_login.UseVisualStyleBackColor = true;
            this.button_login.Click += new System.EventHandler(this.button_login_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(302, 36);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(380, 255);
            this.dataGridView3.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "* Indicates required field";
            // 
            // Patient_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(738, 325);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.button_login);
            this.Controls.Add(this.textBox_patientssn);
            this.Controls.Add(this.textBox_patientpid);
            this.Controls.Add(this.label_patientssn);
            this.Controls.Add(this.label_patientpid);
            this.Name = "Patient_Login";
            this.Text = "Patient_Login";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_patientpid;
        private System.Windows.Forms.Label label_patientssn;
        private System.Windows.Forms.TextBox textBox_patientpid;
        private System.Windows.Forms.TextBox textBox_patientssn;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label1;
    }
}